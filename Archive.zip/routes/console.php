<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

