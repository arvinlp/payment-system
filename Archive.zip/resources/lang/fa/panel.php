<?php
return [
    'ltr'=>'rtl',
];