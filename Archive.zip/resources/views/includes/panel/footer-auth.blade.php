
</div>
</div>
</div>
</div>
</div>

</div>
<!-- partial:partials/_footer.html -->
<footer
    class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
    <a class="text-muted mb-1 mb-md-0" href="https://arvinlp.ir">
        @lang('طراحی و توسعه توسط آروین لری پور')</a>.
    </a>
</footer>
<!-- partial -->

</div>
</div>
<!-- core:js -->
<script src="{{ asset('panel/vendors/core/core.js') }}"></script>
<!-- endinject -->
<!-- Vira -->

<!-- End Vira -->
<!-- Plugin js for this page -->
<script src="{{ asset('panel/vendors/feather-icons/feather.min.js') }}"></script>
<!-- End plugin js for this page -->

<!-- inject:js -->
<script src="{{ asset('panel/js/template.js') }}"></script>
<!-- endinject -->

@yield('js')
</body>

</html>
