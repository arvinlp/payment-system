@include('includes.panel.header-auth')
<!-- partial:partials/_navbar.html -->
<!-- partial -->

<div class="page-content">
    @yield('content')
</div>

@include('includes.panel.footer-auth')
