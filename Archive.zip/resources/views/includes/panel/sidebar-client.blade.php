{{-- <li class="nav-item nav-category">@lang('دسترسی آسان')</li>
<li class="nav-item">
    <a href="{{ route('client.dashboard') }}" class="nav-link">
        <i class="link-icon" data-feather="inbox"></i>
        <span class="link-title">@lang('داشبورد کاربری')</span>
    </a>
</li>

<li class="nav-item">
    <a href="{{ route('client.accounts') }}" class="nav-link">
        <i class="link-icon" data-feather="clock"></i>
        <span class="link-title">@lang('سرویس‌های من')</span>
    </a>
</li>

<li class="nav-item">
    <a href="{{ route('client.payments') }}" class="nav-link">
        <i class="link-icon" data-feather="box"></i>
        <span class="link-title">@lang('پرداخت‌های من')</span>
    </a>
</li> --}}
